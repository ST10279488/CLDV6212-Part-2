﻿using Azure.Data.Tables;
using Azure;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using Microsoft.AspNetCore.Routing;

namespace WebApplication5.Function1
{
    public class Funtion1
    {
        public static class AddNameFunction
        {
            private class NameEntity : ITableEntity
            {
                public string PartitionKey { get; set; }
                public string RowKey { get; set; }
                public string Name { get; set; }
                public ETag ETag { get; set; }
                public DateTimeOffset? Timestamp { get; set; }
            }
        }
    }

    internal class AuthorizationLevel
    {
    }

    internal class FunctionNameAttribute : Attribute
    {
        public FunctionNameAttribute(string v)
        {
        }
    }
}

namespace WebApplication5
{
    class HttpTriggerAttribute : Attribute
    {
    }
}