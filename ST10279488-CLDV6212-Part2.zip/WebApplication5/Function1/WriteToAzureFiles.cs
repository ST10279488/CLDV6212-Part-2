﻿namespace st10279488cldvPart1.Function1
{
    using System.IO;
    using Microsoft.AspNetCore.Mvc;
    using Azure.Storage.Files.Shares;
    using Microsoft.Extensions.Logging;
    using WebApplication5.Function1;
    using WebApplication5;

    public static class WriteToAzureFiles
    {
        [FunctionName("WriteToAzureFiles")]
        public static async Task<IActionResult> Run(
            [HttpTrigger] HttpRequest req, ILogger log)
        {
            log.LogInformation("Writing file to Azure Files.");

            string fileName = req.Query["fileName"];
            string fileContent = await new StreamReader(req.Body).ReadToEndAsync();
            byte[] byteArray = System.Text.Encoding.UTF8.GetBytes(fileContent);

            string storageConnectionString = Environment.GetEnvironmentVariable("AzureWebJobsStorage");
            ShareClient shareClient = new ShareClient(storageConnectionString, "contracts-logs");
            await shareClient.CreateIfNotExistsAsync();

            ShareDirectoryClient directoryClient = shareClient.GetRootDirectoryClient();
            ShareFileClient fileClient = directoryClient.GetFileClient(fileName);

            using (var stream = new MemoryStream(byteArray))
            {
                await fileClient.CreateAsync(stream.Length);
                await fileClient.UploadAsync(stream);
            }

            return new OkObjectResult($"File {fileName} uploaded to Azure Files successfully.");
        }
    }

}
