﻿namespace st10279488cldvPart1.Function1
{
    using System.IO;
    using Microsoft.AspNetCore.Mvc;
    using Azure.Storage.Blobs;
    using Microsoft.Extensions.Logging;
    using WebApplication5.Function1;
    using WebApplication5;

    public static class UploadToBlobStorage
    {
        [FunctionName("UploadToBlobStorage")]
        public static async Task<IActionResult> Run(
            [HttpTrigger] HttpRequest req, ILogger log)
        {
            log.LogInformation("Uploading image to Blob Storage.");

            string fileName = req.Query["fileName"];
            string fileContent = await new StreamReader(req.Body).ReadToEndAsync();
            byte[] byteArray = System.Text.Encoding.UTF8.GetBytes(fileContent);

            string storageConnectionString = Environment.GetEnvironmentVariable("AzureWebJobsStorage");
            BlobServiceClient blobServiceClient = new BlobServiceClient(storageConnectionString);
            BlobContainerClient containerClient = blobServiceClient.GetBlobContainerClient("product-images");
            await containerClient.CreateIfNotExistsAsync();

            BlobClient blobClient = containerClient.GetBlobClient(fileName);
            using (var stream = new MemoryStream(byteArray))
            {
                await blobClient.UploadAsync(stream, overwrite: true);
            }

            return new OkObjectResult($"File {fileName} uploaded successfully.");
        }
    }

}
