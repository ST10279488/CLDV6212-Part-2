﻿namespace st10279488cldvPart1.Function1
{
    using System.IO;
    using Microsoft.AspNetCore.Mvc;
    using Azure;
    using Azure.Data.Tables;
    using Microsoft.Extensions.Logging;
    using WebApplication5.Function1;
    using WebApplication5;

    public static class StoreToAzureTable
    {
        [FunctionName("StoreToAzureTable")]
        public static async Task<IActionResult> Run(
            [HttpTrigger] HttpRequest req, ILogger log)
        {
            log.LogInformation("Storing data to Azure Table.");

            string customerId = req.Query["customerId"];
            string name = req.Query["name"];
            string email = req.Query["email"];

            string storageConnectionString = Environment.GetEnvironmentVariable("AzureWebJobsStorage");
            TableServiceClient tableServiceClient = new TableServiceClient(storageConnectionString);
            TableClient tableClient = tableServiceClient.GetTableClient("CustomerProfiles");
            await tableClient.CreateIfNotExistsAsync();

            var customer = new TableEntity(customerId, Guid.NewGuid().ToString())
        {
            { "Name", name },
            { "Email", email }
        };

            await tableClient.AddEntityAsync(customer);

            return new OkObjectResult($"Customer profile for {name} stored successfully.");
        }
    }

}
