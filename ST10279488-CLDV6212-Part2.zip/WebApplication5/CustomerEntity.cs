﻿namespace WebApplication5
{
    using Azure;
    using Azure.Data.Tables;
    using System;
    using System.Threading.Tasks;

    public class CustomerEntity : ITableEntity
    {
        public string PartitionKey { get; set; }
        public string RowKey { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public DateTimeOffset? Timestamp { get; set; }
        public ETag ETag { get; set; }
    }

    public class AzureTableService
    {
        private readonly string _connectionString;
        private readonly string _tableName = "CustomerProfiles";

        public AzureTableService(string connectionString)
        {
            _connectionString = connectionString;
        }

        public async Task AddCustomerAsync(string customerId, string name, string email)
        {
            TableClient tableClient = new TableClient(_connectionString, _tableName);
            await tableClient.CreateIfNotExistsAsync();

            CustomerEntity customer = new CustomerEntity
            {
                PartitionKey = "Customer",
                RowKey = customerId,
                Name = name,
                Email = email
            };

            await tableClient.AddEntityAsync(customer);
        }
    }
}
