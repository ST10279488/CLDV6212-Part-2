﻿namespace WebApplication5
{
    
    using System.Collections.Generic;
    using WebApplication5.Models;

    public static class ProductRepository
    {
        public static List<Product> GetAllProducts()
        {
            return new List<Product>
        {
            new Product
            {
                Id = 1,
                Name = "Wireless Mouse",
                Description = "A high-quality wireless mouse with ergonomic design.",
                Price = 25.99M,
                ImageUrl = "/images/wireless-mouse.jpg"
            },
            new Product
            {
                Id = 2,
                Name = "Mechanical Keyboard",
                Description = "A durable mechanical keyboard with customizable RGB backlighting.",
                Price = 79.99M,
                ImageUrl = "/images/mechanical-keyboard.jpg"
            },
            new Product
            {
                Id = 3,
                Name = "27-inch Monitor",
                Description = "A high-resolution 27-inch monitor with vivid colors.",
                Price = 299.99M,
                ImageUrl = "/images/27-inch-monitor.jpg"
            },
            new Product
            {
                Id = 4,
                Name = "Gaming Headset",
                Description = "Comfortable gaming headset with surround sound.",
                Price = 59.99M,
                ImageUrl = "/images/gaming-headset.jpg"
            },
            new Product
            {
                Id = 5,
                Name = "Laptop Stand",
                Description = "An adjustable laptop stand for better ergonomics.",
                Price = 39.99M,
                ImageUrl = "/images/laptop-stand.jpg"
            }
        };
        }
    }

}
