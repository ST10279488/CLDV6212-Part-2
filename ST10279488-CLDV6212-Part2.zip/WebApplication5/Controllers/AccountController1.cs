﻿using Microsoft.AspNetCore.Mvc;
using WebApplication5.Models;

namespace WebApplication5.Controllers
{
    public class AccountController1 : Controller
    {
       

        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Register(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
               
                ViewBag.Message = "User registered successfully!";
                return RedirectToAction("Index", "Home");
            }
            return View(model);
        }
    }

}

