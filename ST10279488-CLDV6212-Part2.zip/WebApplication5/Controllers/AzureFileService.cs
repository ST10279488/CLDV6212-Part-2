﻿
namespace WebApplication5.Controllers
{
    internal class AzureFileService
    {
        internal Task UploadFileAsync(Stream stream, string fileName)
        {
            throw new NotImplementedException();
        }
    }
}