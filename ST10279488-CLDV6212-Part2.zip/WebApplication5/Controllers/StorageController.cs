﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication5.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using System.IO;
    using System.Threading.Tasks;
    using WebApplication5.Models;

    public class StorageController : Controller
    {
        private readonly AzureBlobService _blobService;
        private readonly AzureQueueService _queueService;
        private readonly AzureTableService _tableService;
        private readonly AzureFileService _fileService;

        
        [HttpPost]
        public async Task<IActionResult> CreateCustomer(CustomerModel model)
        {
            if (ModelState.IsValid)
            {
                await _tableService.AddCustomerAsync(model.CustomerId, model.Name, model.Email);
                return RedirectToAction("CustomerSuccess");
            }
            return View(model);
        }

        // File Upload Action
        [HttpPost]
        public async Task<IActionResult> UploadImage(FileUploadModel model)
        {
            if (model.File != null && model.File.Length > 0)
            {
                using var stream = model.File.OpenReadStream();
                await _blobService.UploadImageAsync(stream, model.File.FileName);
                return RedirectToAction("FileUploadSuccess");
            }
            return View(model);
        }

        // Order Processing Action
        [HttpPost]
        public async Task<IActionResult> CreateOrder(OrderModel model)
        {
            if (ModelState.IsValid)
            {
                var orderDetails = $"OrderID: {model.OrderId}, Product: {model.ProductName}, Quantity: {model.Quantity}";
                await _queueService.AddOrderToQueueAsync(orderDetails);
                return RedirectToAction("OrderSuccess");
            }
            return View(model);
        }

        // Contract Upload Action
        [HttpPost]
        public async Task<IActionResult> UploadContract(FileUploadModel model)
        {
            if (model.File != null && model.File.Length > 0)
            {
                using var stream = model.File.OpenReadStream();
                await _fileService.UploadFileAsync(stream, model.File.FileName);
                return RedirectToAction("ContractUploadSuccess");
            }
            return View(model);
        }

        // Success pages
        public IActionResult CustomerSuccess() => View();
        public IActionResult FileUploadSuccess() => View();
        public IActionResult OrderSuccess() => View();
        public IActionResult ContractUploadSuccess() => View();
    }


}

