﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using WebApplication5;

public class ProductController : Controller
{
    public IActionResult Index()
    {
        return View(); 
    }

    private readonly ILogger<ProductController> _logger;

    public ProductController(ILogger<ProductController> logger)
    {
        _logger = logger;
    }

    public IActionResult index()
    {
        try
        {
            var products = ProductRepository.GetAllProducts();
            return View(products);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error fetching products");
            return StatusCode(500, "Internal server error");
        }
    }
}

