﻿namespace WebApplication5.Controllers
{
    public class Product
    {
    }
}