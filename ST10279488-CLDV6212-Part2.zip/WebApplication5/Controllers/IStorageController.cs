﻿using Microsoft.AspNetCore.Mvc;
using WebApplication5.Models;

namespace WebApplication5.Controllers
{
    public interface IStorageController
    {
        IActionResult ContractUploadSuccess();
        Task<IActionResult> CreateCustomer(CustomerModel model);
        Task<IActionResult> CreateOrder(OrderModel model);
        IActionResult CustomerSuccess();
        IActionResult FileUploadSuccess();
        IActionResult OrderSuccess();
        Task<IActionResult> UploadContract(FileUploadModel model);
        Task<IActionResult> UploadImage(FileUploadModel model);
    }
}