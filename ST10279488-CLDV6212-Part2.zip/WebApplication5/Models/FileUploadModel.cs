﻿namespace WebApplication5.Models
{
    using Microsoft.AspNetCore.Http;

    public class FileUploadModel
    {
        public IFormFile File { get; set; }
    }

}
