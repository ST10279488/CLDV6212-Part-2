﻿namespace WebApplication5.Models
{
    public class CustomerModel
    {
        public string CustomerId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
    }

}
