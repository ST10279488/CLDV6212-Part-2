﻿namespace WebApplication5.Models
{
    public class OrderModel
    {
        public string OrderId { get; set; }
        public string ProductName { get; set; }
        public int Quantity { get; set; }
    }

}
