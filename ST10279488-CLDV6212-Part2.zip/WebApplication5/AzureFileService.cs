﻿namespace WebApplication5
{
    using Azure;
    // Install Azure.Storage.Files.Shares package via NuGet
    using Azure.Storage.Files.Shares;

    public class AzureFileStorageService
    {
        private readonly ShareClient _shareClient;

        public AzureFileStorageService(string connectionString, string shareName)
        {
            _shareClient = new ShareClient(connectionString, shareName);
            _shareClient.CreateIfNotExists();
        }

        public async Task UploadFileAsync(string directoryName, string fileName, Stream content)
        {
            var directoryClient = _shareClient.GetDirectoryClient(directoryName);
            await directoryClient.CreateIfNotExistsAsync();
            var fileClient = directoryClient.GetFileClient(fileName);
            await fileClient.CreateAsync(content.Length);
            await fileClient.UploadRangeAsync(new HttpRange(0, content.Length), content);
        }
    }


}
