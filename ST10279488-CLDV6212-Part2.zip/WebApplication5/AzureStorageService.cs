﻿namespace WebApplication5
{
   // Install Azure.Data.Tables package via NuGet
using Azure.Data.Tables;

public class AzureTableStorageService
{
    private readonly TableClient _tableClient;

    public AzureTableStorageService(string connectionString, string tableName)
    {
        var serviceClient = new TableServiceClient(connectionString);
        _tableClient = serviceClient.GetTableClient(tableName);
        _tableClient.CreateIfNotExists();
    }

    public async Task AddEntityAsync<T>(T entity) where T : class, ITableEntity, new()
    {
        await _tableClient.AddEntityAsync(entity);
    }
}

}
