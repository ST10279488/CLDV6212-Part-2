﻿namespace WebApplication5
{
    using Azure.Storage.Blobs;
    using Azure.Storage.Blobs.Models;
    using System.IO;
    using System.Threading.Tasks;

    public class AzureBlobService
    {
        private readonly string _blobConnectionString = "DefaultEndpointsProtocol=https;AccountName=st10279488cldv;AccountKey=gk5kjOJ7j0Y9f9O8wcMASSB2Ifol4kI4VE1ngFh1r0A9pjfOM6W/t3wmWzYqfDlOsNSburEVTkfG+AStPlxTUA==;EndpointSuffix=core.windows.net";
        private readonly string _containerName = "productimages";

        public AzureBlobService(string blobConnectionString)
        {
            _blobConnectionString = blobConnectionString;
        }

        public async Task UploadImageAsync(Stream fileStream, string fileName)
        {
            BlobContainerClient containerClient = new BlobContainerClient(_blobConnectionString, _containerName);
            await containerClient.CreateIfNotExistsAsync(PublicAccessType.Blob);

            BlobClient blobClient = containerClient.GetBlobClient(fileName);
            await blobClient.UploadAsync(fileStream, true);
        }
    }

}
