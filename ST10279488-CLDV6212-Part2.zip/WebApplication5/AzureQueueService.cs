﻿namespace WebApplication5
{
    // Install Azure.Storage.Queues package via NuGet
    using Azure.Storage.Queues;
    using System;

    public class AzureQueueService
    {
        private readonly QueueClient _queueClient;
        private string azureStorageConnectionString = "DefaultEndpointsProtocol=https;AccountName=st10279488cldv;AccountKey=gk5kjOJ7j0Y9f9O8wcMASSB2Ifol4kI4VE1ngFh1r0A9pjfOM6W/t3wmWzYqfDlOsNSburEVTkfG+AStPlxTUA==;EndpointSuffix=core.windows.net";

        public AzureQueueService(string azureStorageConnectionString)
        {
            this.azureStorageConnectionString = azureStorageConnectionString;
        }

        public AzureQueueService(string connectionString, string queueName)
        {
            _queueClient = new QueueClient(connectionString, queueName);
            _queueClient.CreateIfNotExists();
        }

        public async Task AddMessageAsync(string message)
        {
            await _queueClient.SendMessageAsync(message);
        }

        public async Task<string?> RetrieveMessageAsync()
        {
            var message = await _queueClient.ReceiveMessageAsync();
            if (message.Value != null)
            {
                await _queueClient.DeleteMessageAsync(message.Value.MessageId, message.Value.PopReceipt);
                return message.Value.MessageText;
            }

            return null;
        }

        internal Task AddOrderToQueueAsync(string orderDetails)
        {
            throw new NotImplementedException();
        }
    }


}
